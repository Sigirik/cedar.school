import React from "react";
import TemplateWeekEditor from "./components/TemplateWeekEditor";

function App() {
  return (
    <div>
      <TemplateWeekEditor />
    </div>
  );
}

export default App;