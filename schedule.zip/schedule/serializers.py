from rest_framework import serializers
from .models import KTPTemplate, KTPSection, KTPEntry, TemplateWeekDraft, TemplateWeek, TemplateLesson


class KTPEntrySerializer(serializers.ModelSerializer):
    class Meta:
        model = KTPEntry
        fields = '__all__'

class KTPSectionSerializer(serializers.ModelSerializer):
    entries = KTPEntrySerializer(many=True, read_only=True)

    class Meta:
        model = KTPSection
        fields = '__all__'

class KTPTemplateSerializer(serializers.ModelSerializer):
    sections = KTPSectionSerializer(many=True, read_only=True)

    class Meta:
        model = KTPTemplate
        fields = '__all__'

class TemplateWeekDraftSerializer(serializers.ModelSerializer):
    user = serializers.HiddenField(default=serializers.CurrentUserDefault())

    class Meta:
        model = TemplateWeekDraft
        fields = "__all__"

class TemplateLessonSerializer(serializers.ModelSerializer):
    class Meta:
        model = TemplateLesson
        fields = ["id", "subject", "grade", "teacher", "day_of_week", "start_time", "duration_minutes"]

class TemplateWeekDetailSerializer(serializers.ModelSerializer):
    lessons = serializers.SerializerMethodField()

    class Meta:
        model = TemplateWeek
        fields = ["id", "name", "academic_year", "created_at", "is_active", "lessons"]

    def get_lessons(self, obj):
        lessons = TemplateLesson.objects.filter(template_week=obj)
        return TemplateLessonSerializer(lessons, many=True).data

class TemplateWeekSerializer(serializers.ModelSerializer):
    class Meta:
        model = TemplateWeek
        fields = "__all__"

from .models import Subject, Grade
from django.contrib.auth import get_user_model

User = get_user_model()

class SubjectSerializer(serializers.ModelSerializer):
    class Meta:
        model = Subject
        fields = ["id", "name"]

class GradeSerializer(serializers.ModelSerializer):
    class Meta:
        model = Grade
        fields = ["id", "name"]

class TeacherSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ["id", "username"]
