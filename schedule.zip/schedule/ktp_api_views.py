
from rest_framework import viewsets
from .models import KTPTemplate, KTPSection, KTPEntry
from .serializers import KTPTemplateSerializer, KTPSectionSerializer, KTPEntrySerializer

class KTPTemplateViewSet(viewsets.ModelViewSet):
    queryset = KTPTemplate.objects.all()
    serializer_class = KTPTemplateSerializer

class KTPSectionViewSet(viewsets.ModelViewSet):
    queryset = KTPSection.objects.all()
    serializer_class = KTPSectionSerializer

class KTPEntryViewSet(viewsets.ModelViewSet):
    queryset = KTPEntry.objects.all()
    serializer_class = KTPEntrySerializer

from rest_framework import viewsets
from .models import Subject, Grade
from django.contrib.auth import get_user_model
from .serializers import SubjectSerializer, GradeSerializer, TeacherSerializer

User = get_user_model()

class SubjectViewSet(viewsets.ReadOnlyModelViewSet):
    queryset = Subject.objects.all()
    serializer_class = SubjectSerializer

class GradeViewSet(viewsets.ReadOnlyModelViewSet):
    queryset = Grade.objects.all()
    serializer_class = GradeSerializer

class TeacherViewSet(viewsets.ReadOnlyModelViewSet):
    queryset = User.objects.filter(role="TEACHER")
    serializer_class = TeacherSerializer