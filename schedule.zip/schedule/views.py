from django.shortcuts import render, redirect
from .models import RealLesson, TemplateWeek, TemplateLesson
from .forms import TemplateLessonForm
from rest_framework.views import APIView
from rest_framework.response import Response
from .serializers import TemplateWeekDetailSerializer

def template_week_view(request):
    lessons = TemplateLesson.objects.all()
    form = TemplateLessonForm()

    if request.method == 'POST':
        form = TemplateLessonForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('template_week')

    return render(request, 'schedule/template_week.html', {
        'form': form,
        'lessons': lessons
    })


from .models import RealLesson

def real_lesson_list_view(request):
    lessons = RealLesson.objects.order_by('date', 'start_time')
    return render(request, 'schedule/real_lesson_list.html', {
        'lessons': lessons
    })

from django.shortcuts import render, redirect
from .forms import RealLessonForm

def real_lesson_create_view(request):
    form = RealLessonForm(request.POST or None)
    if request.method == "POST" and form.is_valid():
        form.save()
        return redirect('real_lesson_list')  # или другой маршрут
    return render(request, 'schedule/real_lesson_form.html', {'form': form})

from django.http import JsonResponse, Http404
from django.views.decorators.http import require_GET
from .models import TemplateLesson

@require_GET
def template_lesson_detail_json(request, pk):
    try:
        lesson = TemplateLesson.objects.get(pk=pk)
    except TemplateLesson.DoesNotExist:
        raise Http404("Шаблон не найден")

    data = {
        "subject": lesson.subject.id,
        "teacher": lesson.teacher.id,
        "grade": lesson.grade.id,
        "start_time": lesson.start_time.strftime("%H:%M"),
        "duration_minutes": lesson.duration_minutes,
    }
    return JsonResponse(data)

class ActiveTemplateWeekView(APIView):
    def get(self, request):
        active_week = TemplateWeek.objects.filter(is_active=True).order_by("-created_at").first()
        if not active_week:
            return Response({"detail": "No active template week found."}, status=404)
        data = TemplateWeekDetailSerializer(active_week).data
        return Response(data)
